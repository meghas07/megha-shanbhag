
public class Debit extends Card {

	private float maxWtihdrawal;
	private int accLinked;
	/**
	* 
	*/
	private static final long serialVersionUID = 6363181683217599949L;

	public Debit(CardType CARDTYPE, long cardNum, String pAN, String name, long contact, float maxWtihdrawal,
			int accLinked) {
		super(cardNum, pAN, name, contact);
		this.maxWtihdrawal = maxWtihdrawal;
		this.accLinked = accLinked;
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Debit Card Details:\n" + "Card Number:" + getCardNum() + "\n" + "Holder Name:" + getName() + "\n"
				+ "PAN Number:" + getPAN() + "\n" + "Phone Number:" + getContact() + "\n" + "Account linked" + "\n"
				+ accLinked + "\n";

	}

}
