import java.util.Scanner;

public class App {

	public static void main(String[] args) {

		System.out.println("Welcome user");
		/**
		 * main method calls loadCard() method of CardStorr class and loads all
		 * data present in the text file into an array
		 */
		CardStore.loadCard();
		/**
		 * After loading, menu() method is called .
		 */
		// CardStore.print();
		menu();
	}

	public static void menu() {
		int cardChoice;
		long cardNumber;
		String holderName;
		int choice;

		/**
		 * Display menu for user at least while using do while loop
		 */
		do {
			System.out.println("Please Select an option \n " + "1.Add/Generate a new card \n "
					+ "2.Find card by number \n" + " 3.Find card by holder name \n" + " 4.quit application");
			System.out.println("Enter option number ");
			Scanner sc = new Scanner(System.in);
			choice = sc.nextInt();

			if (choice == 1) {
				/*
				 * asks user if they want a credit or debit card and passes the
				 * value back to function
				 */
				sc.nextLine();
				System.out.println("Please enter the following details:\n");
				System.out.println("Type of card:1.Credit or 2.debit ");
				cardChoice = sc.nextInt();
				switch (cardChoice) {
				case 1:
					CardStore.addCard(CardFactory.issueNewCard(CardType.CREDIT));
					break;
				case 2:
					CardStore.addCard(CardFactory.issueNewCard(CardType.DEBIT));
					break;

				default:
					System.out.println("invalid choice");
				}// end of switch
			} // end of choice 1

			/*
			 * This option is used for finding cards by their number,it take
			 * value from user and passes the value back to function
			 * findCardByNumber in CardStore class
			 */
			else if (choice == 2) {
				System.out.println("Enter card number");
				cardNumber = sc.nextLong();
				CardStore.findCardByNumber(cardNumber);
			}

			/*
			 * This option is used for finding cards by their name,it take value
			 * from user and passes the value back to function findCardByName in
			 * CardStore class
			 */
			else if (choice == 3) {
				System.out.println("Enter Holder Name:");
				sc.nextLine();
				holderName = sc.nextLine();

				CardStore.findCardByName(holderName);

			}

			/**
			 * this option is used to quit the application after which the store
			 * function is called(outside the do-while loop) which stores all
			 * the data from the cardList array into the text file
			 * 
			 */
			else if (choice == 4)
				System.out.println("you have quit the application");

			else
				System.out.println("Invalid Input.");

		} while (choice != 4);
		/**
		 * stores all card data from array into cardData.dat file in binary
		 * format
		 */
		CardStore.storeCard();
	}
}
