import java.io.*;

public abstract class Card implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1895911728440137785L;
	@Override
	public String toString() {
		return "Card [cardNum=" + cardNum + ", PAN=" + PAN + ", name=" + name + ", contact=" + contact + "]";
	}
	private long cardNum;
	private String PAN;
	private String name;
	private long contact;
	public Card(long cardNum, String pAN, String name, long contact) {
		super();
		this.cardNum = cardNum;
		PAN = pAN;
		this.name = name.toLowerCase();
		this.contact = contact;
	}
	public long getCardNum() {
		return cardNum;
	}
	public String getPAN() {
		return PAN;
	}
	public String getName() {
		return name;
	}
	public long getContact() {
		return contact;
	}
	
}
