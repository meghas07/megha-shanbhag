
public class Credit extends Card {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6363181683217599949L;
	private float interestRate;
	private float creditLimit;
	private int pointsEarned;

	@Override
	public String toString() {
		return "Credit Card Details:"+ "\n" + " CardNumber=" + getCardNum()+ "\n" + " Name=" + getName()+ "\n" + " Phone Number="
				+ getContact()+ "\n" + "PAN=" + getPAN() + "\n"+ " InterestRate =" + interestRate+ "\n" + " CreditLimit=" + creditLimit
				+ "\n"+ " PointsEarned=" + pointsEarned + "\n";
	}

	public Credit(CardType CARDTYPE, long cardNum, String PAN, String name, long contact, float interestRate,
			float creditLimit, int pointsEarned) {
		super(cardNum, PAN, name, contact);
		this.interestRate = interestRate;
		this.creditLimit = creditLimit;
		this.pointsEarned = pointsEarned;

	}

}
