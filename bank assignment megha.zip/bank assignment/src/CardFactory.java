import java.util.Scanner;

public class CardFactory {
	static long actNum;

	public static Card issueNewCard(CardType CARDTYPE) {
		// all input variables that have be to be given by customer
		String name, PAN;
		long phoneNum;
		float interestRate, creditLimit, maxWtihdrawal;
		int pointsEarned, accLinked;
		Scanner sc = new Scanner(System.in);
		// taking input from the customer for card type=credit
		if (CARDTYPE == CardType.CREDIT) {
			System.out.println("Name: ");
			name = sc.nextLine();
			System.out.println("PAN number: ");
			PAN = sc.nextLine();
			System.out.println("Phone Number ");
			phoneNum = sc.nextLong();
			System.out.println("Enter Interest Rate");
			interestRate = sc.nextFloat();
			System.out.println("Enter Credit Limit");
			creditLimit = sc.nextFloat();
			System.out.println("EnterPoints Earned");
			pointsEarned = sc.nextInt();
			// generating unique car number
			actNum = System.currentTimeMillis();
			// creating a card object of type credit
			Card c1 = new Credit(CARDTYPE, actNum, PAN, name, phoneNum, interestRate, creditLimit, pointsEarned);
			// returning back card object to add function
			return c1;
		} // end of if function
		else if (CARDTYPE == CardType.DEBIT) {
			System.out.println("Name: ");
			name = sc.nextLine();
			System.out.println("PAN number: ");
			PAN = sc.nextLine();
			System.out.println("Phone Number ");
			phoneNum = sc.nextLong();
			System.out.println("Enter Maximum withdrawal amount:");
			maxWtihdrawal = sc.nextFloat();
			System.out.println("Enter number of account linked");
			accLinked = sc.nextInt();
			actNum = System.currentTimeMillis();
			Card c1 = new Debit(CARDTYPE, actNum, PAN, name, phoneNum, maxWtihdrawal, accLinked);
			return c1;
		}
		// end of if else loop,return null if both conditions are false
		return null;

	}

}
