
public enum CardType {
	
	CREDIT,DEBIT;

}
