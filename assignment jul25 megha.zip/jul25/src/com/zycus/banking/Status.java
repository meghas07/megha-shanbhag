package com.zycus.banking;

public enum Status {

	ACTIVE, CLOSED;
}
