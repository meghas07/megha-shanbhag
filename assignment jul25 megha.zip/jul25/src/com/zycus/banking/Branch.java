package com.zycus.banking;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Branch {
	private static int ACC_NO_GENERATOR = 1;

	Map<Integer, Account> accountList = new HashMap<Integer, Account>();

	public void openNewAccount(AccountType type, String accountHolder, float balance) {

		accountList.put(ACC_NO_GENERATOR, new Account(ACC_NO_GENERATOR, accountHolder, balance, type, Status.ACTIVE));
		ACC_NO_GENERATOR++;

	}

	public Account getAccount(int actNum) {
		return accountList.get(actNum);

	}

	public void closeAccount(int actNum) {

		accountList.get(actNum).setStatus(Status.CLOSED);

	}

	public List getAllAccounts() {

		List<Account> list = new ArrayList<Account>(accountList.values());
		return list;
	}

	public Set<Account> findByAccountHolder(String accountHolder) {

		return accountList.values().stream()
				.filter((name) -> name.getAccountHolder().equalsIgnoreCase(accountHolder.trim()))
				.collect(Collectors.toSet());

	}

}
