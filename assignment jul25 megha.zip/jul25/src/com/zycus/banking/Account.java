package com.zycus.banking;

public class Account {

	private int accountNum;
	private static int branchCode;
	private String accountHolder;
	private float balance;
	private AccountType accountType;
	private Status status;

	/**
	 * getters for all fields with public access specifier
	 * 
	 * @return
	 */
	public int getAccountNum() {
		return accountNum;
	}

	public static int getBranchCode() {
		return branchCode;
	}

	public String getAccountHolder() {
		return accountHolder;
	}

	public float getBalance() {
		return balance;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public Status getStatus() {
		return status;
	}

	/**
	 * setters for all fields with no access specifier
	 * 
	 * @param accountNum
	 */

	void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}

	static void setBranchCode(int branchCode) {
		Account.branchCode = branchCode;
	}

	void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}

	void setBalance(float balance) {
		this.balance = balance;
	}

	void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	void setStatus(Status status) {
		this.status = status;
	}

	/**
	 * Constructor with no access specifier
	 * 
	 * @param accountNum
	 * @param accountHolder
	 * @param balance
	 * @param accountType
	 * @param status
	 */
	Account(int accountNum, String accountHolder, float balance, AccountType type, Status status) {
		super();
		this.accountNum = accountNum;
		this.accountHolder = accountHolder;
		this.balance = balance;
		this.accountType = type;
		this.status = status;
	}

	@Override
	public String toString() {
		return "AccountNum=" + accountNum + ", accountHolder=" + accountHolder + ", balance=" + balance
				+ ", accountType=" + accountType + ", status=" + status + "\n";
	}

}
