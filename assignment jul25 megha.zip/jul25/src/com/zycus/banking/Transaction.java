package com.zycus.banking;

public class Transaction {

	Branch branch = new Branch();
	float newBal;

	public Transaction(Branch branch) {
		super();
		this.branch = branch;
	}

	/*
	 * withdraw method to withdraw money from account
	 */
	public boolean withdraw(int actNum, float amt) {
		Account a1 = branch.getAccount(actNum);
		if (a1 != null) {
			if (a1.getStatus() == Status.ACTIVE) {
				newBal = a1.getBalance() - amt;
				if (newBal < 1000) {

					return false;

				} else {
					a1.setBalance(newBal);
					return true;

				}
			}
		}
		return false;
	}

	/*
	 * deposit method to deposit money into account
	 */
	public boolean deposit(int actNum, float amt) {
		Account a2 = branch.getAccount(actNum);
		if (a2 != null) {
			if (a2.getStatus() == Status.ACTIVE) {
				newBal = a2.getBalance() + amt;
				a2.setBalance(newBal);
				return true;
			}
		}
		return false;
	}

	/*
	 * transfer method to transfer money into someonelese's account
	 */
	public boolean transfer(int sourceAccountNum, int targetAccountNum, float amt) {

		if (withdraw(sourceAccountNum, amt)) {
			if (deposit(targetAccountNum, amt)) {
				return true;
			} else {

				deposit(sourceAccountNum, amt);
				return false;
			}

		}
		return false;
	}

}
