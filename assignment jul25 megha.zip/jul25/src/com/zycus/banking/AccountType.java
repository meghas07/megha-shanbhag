package com.zycus.banking;

public enum AccountType {
	SAVINGS, CURRENT;
}
