package com.zycus.banking;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class App {

	public static void main(String[] args) {

		Branch b1 = new Branch();

		b1.openNewAccount(AccountType.SAVINGS, "Megha", 60000);
		b1.openNewAccount(AccountType.SAVINGS, "Sonali", 20000);
		b1.openNewAccount(AccountType.CURRENT, "Diksha", 10000);
		b1.openNewAccount(AccountType.CURRENT, "Suyog", 6000);
		b1.openNewAccount(AccountType.SAVINGS, "Akshay", 6500);
		b1.openNewAccount(AccountType.SAVINGS, "Aditya", 45000);
		b1.openNewAccount(AccountType.CURRENT, "Pranali", 60000);
		b1.openNewAccount(AccountType.SAVINGS, "Amar", 2300);
		b1.openNewAccount(AccountType.CURRENT, "abc", 8000);
		b1.openNewAccount(AccountType.CURRENT, "xyz", 5750);

		b1.closeAccount(4);

		printWithdraw(1, 1000, b1);
		printWithdraw(2, 5000, b1);

		printTransfer(1, 2, 1000, b1);

		/*
		 * All accounts
		 */
		System.out.println("List of all accounts \n" + b1.getAllAccounts() + "\n\n\n");

		/*
		 * accounts sorted by balance
		 */

		System.out.println("list of all account sorted by balance:");
		List<Account> tempList = new ArrayList(b1.getAllAccounts());
		Collections.sort(tempList, new SortByBalance());
		for (Account an : tempList)
			System.out.println(an);
		System.out.println("\n");

		/*
		 * accounts sorted by account number
		 */
		System.out.println("list of all account sorted by Account Number:");
		List<Account> newList = new ArrayList(b1.getAllAccounts());
		Collections.sort(newList, new SortByBalance());
		for (Account ab : newList)
			System.out.println(ab);
		System.out.println("\n");

		/*
		 * all accounts listed by type current
		 */
		System.out.println("list of all accounts of type CURRENT:");
		List<Account> result = tempList.stream().filter(x -> x.getAccountType() == AccountType.CURRENT)
				.collect(Collectors.toList());
		for (Account a : result)
			System.out.println(a);
		System.out.println("\n");

		/*
		 * all accounts listed by type savings
		 */
		System.out.println("list of all accounts of type SAVINGS:");
		List<Account> result1 = tempList.stream().filter((x) -> x.getAccountType() == AccountType.SAVINGS)
				.collect(Collectors.toList());
		for (Account a1 : result1)
			System.out.println(a1);
		System.out.println("\n");

		/*
		 * all accounts that are closed but have balance>5000
		 */
		List<Account> result2 = tempList.stream().filter((x) -> x.getStatus() == Status.CLOSED)
				.filter((bal) -> bal.getBalance() > 5000).collect(Collectors.toList());
		for (Account a3 : result2)
			System.out.println(a3);
		System.out.println("\n");

	}

	/*
	 * call withdraw function in transaction class
	 */
	public static void printWithdraw(int num, float amt, Branch b) {

		Transaction t1 = new Transaction(b);
		if (t1.withdraw(num, amt)) {
			System.out.println("Withdraw successful\n");
			System.out.println(b.getAccount(num));
		} else
			System.out.println("Withdraw unsuccessful\n");

	}
	/*
	 * call Deposit function in transaction class
	 */

	public void printDeposit(int num, float amt, Branch b) {
		Transaction t1 = new Transaction(b);
		if (t1.deposit(num, amt)) {
			System.out.println("Deposit successful\n");
			System.out.println(b.getAccount(num));
		} else
			System.out.println("Deposit unsuccessful\n");

	}

	/*
	 * call transfer function in transaction class
	 */
	public static void printTransfer(int source, int target, float amt, Branch b) {

		Transaction t1 = new Transaction(b);
		if (t1.transfer(source, target, amt)) {
			System.out.println("Transfer successful");
			System.out.println("After withdrawal from Account " + b.getAccount(source) + "\n");
			System.out.println("After deposit in Account " + b.getAccount(source) + "\n");
		}
	}

}
