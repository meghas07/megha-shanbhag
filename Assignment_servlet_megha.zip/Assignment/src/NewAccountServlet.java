

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NewAccountServlet
 */
@WebServlet("/createAccount.do")
public class NewAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewAccountServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int age=0;
		
		String firstName=request.getParameter("firstname");
		String lastName=request.getParameter("lastname");
		String title=request.getParameter("title");
		String strage=request.getParameter("age");
		String strdob=request.getParameter("dob");
			
		
		if(firstName==null || lastName==null || title==null || strage==null || strdob==null)
			response.sendRedirect("index.html");
		if(firstName.length()<2 || lastName.length()<2 )
			response.sendRedirect("index.html");		
		if(!strage.equals(""))
		 { 
			
			age=Integer.parseInt(strage); 
			}else{
				
				response.sendRedirect("index.html");
			}
		
	
		Connection con1=ConnectionUtil.getConnection();
		CustomerDAO customer=new CustomerDAO(firstName,lastName,title,age,strdob);
		customer.insertRecord();
		System.out.println(customer.toString());
		PrintWriter message= response.getWriter();
		message.println("Thankyou for choosing us "+title+" "+firstName+" "+lastName+" ,your account is under proccessing");
		
	
		
			
		
		doGet(request, response);
	}

}
