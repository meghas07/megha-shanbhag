
import java.sql.*;

public class CustomerDAO {
	private String firstName,lastName,title,dob;
	private int age;
	public CustomerDAO(String firstName, String lastName, String title, int age, String dob) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.title = title;
		this.age = age;
		this.dob = dob;
	}

	
	private static final String SQL_INSERT="insert into bank_customer(firstname,lastname,title,age,dob)values(?,?,?,?,?)";

	public void insertRecord() {
		try(Connection con = ConnectionUtil.getConnection()){
			PreparedStatement ps = con.prepareStatement(SQL_INSERT);
			ps.setString(1,firstName);
			ps.setString(2, lastName );
			ps.setString(3, title);
			ps.setInt(4,age );
			ps.setString(5,dob );
			ps.executeUpdate();
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}

	
	@Override
	public String toString() {
		return "CustomerDAO [firstName=" + firstName + ", lastName=" + lastName + ", title=" + title + ", dob=" + dob
				+ ", age=" + age + "]";
	}

}
