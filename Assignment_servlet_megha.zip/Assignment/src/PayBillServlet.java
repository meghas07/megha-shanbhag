

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PayBillServlet
 */
@WebServlet("/pay-bill.do")
public class PayBillServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PayBillServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String billType=request.getParameter("billtype");
		String electricProvider=null;
		String phoneProvider=null;
		if(billType.equalsIgnoreCase("electric"))
		{
			electricProvider=request.getParameter("electric_provider");
			phoneProvider="NA";
		}
		else if(billType.equalsIgnoreCase("phone")){
			electricProvider="NA";
			phoneProvider=request.getParameter("phone_provider");
		}
		String accountNum=request.getParameter("acc_no");
		String billAmount=request.getParameter("amount");
		
		BillsDAO billDetail=new BillsDAO(billType,electricProvider,phoneProvider,accountNum,billAmount);
		billDetail.insertRecord();
		System.out.println(billDetail.toString());
		
		PrintWriter message=response.getWriter();
		message.println("<h1 style='text-align:center ; color: #180e89; margin-top:200px'> Your payment has been proccessed successfully!</h1>");
		message.println("<a href='index.html' ><button style='text-align:center; margin-left:500px;'>Take me home</button></a>");
		
	}

}
