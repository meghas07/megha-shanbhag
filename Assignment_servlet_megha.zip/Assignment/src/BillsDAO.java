import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BillsDAO {

	private String billType,electricProvider,phoneProvider,accountNum,billAmount;
	private static final String SQL_INSERT="insert into bills(billtype,electric_provider,phone_provider,accountnum,billamount)values(?,?,?,?,?)";

	
	
	public BillsDAO(String billType, String electricProvider, String phoneProvider, String accountNum,
			String billAmount) {
		super();
		this.billType = billType;
		this.electricProvider = electricProvider;
		this.phoneProvider = phoneProvider;
		this.accountNum = accountNum;
		this.billAmount = billAmount;
	}

	


	@Override
	public String toString() {
		return "BillsDAO [billType=" + billType + ", electricProvider=" + electricProvider + ", phoneProvider="
				+ phoneProvider + ", accountNum=" + accountNum + ", billAmount=" + billAmount + "]";
	}




	public void insertRecord() {
		try(Connection con = ConnectionUtil.getConnection()){
			PreparedStatement ps = con.prepareStatement(SQL_INSERT);
			ps.setString(1,billType);
			ps.setString(2, electricProvider );
			ps.setString(3, phoneProvider);
			ps.setString(4,accountNum );
			ps.setString(5,billAmount );
			ps.executeUpdate();
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}

	
	
	
}
